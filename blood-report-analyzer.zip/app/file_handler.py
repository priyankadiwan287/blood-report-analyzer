import fitz  # PyMuPDF
import pytesseract
from PIL import Image
import io

async def extract_text_from_pdf(file):
    pdf_data = await file.read()
    doc = fitz.open(stream=pdf_data, filetype="pdf")
    text = ""
    for page in doc:
        text += page.get_text()
    return text

async def extract_text_from_image(file):
    image_data = await file.read()
    image = Image.open(io.BytesIO(image_data))
    text = pytesseract.image_to_string(image)
    return text
